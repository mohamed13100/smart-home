/*
 * timer0_prog.c
 *
 *  Created on: Feb 21, 2023
 *      Author: mohamed
 */


