/*
 * timer0_init.h
 *
 *  Created on: Feb 21, 2023
 *      Author: mohamed
 */

#ifndef TIMER0_TIMER0_INIT_H_
#define TIMER0_TIMER0_INIT_H_



#endif /* TIMER0_TIMER0_INIT_H_ */
