/*
 * ADC_config.h
 *
 *  Created on: Feb 16, 2023
 *      Author: majec
 */

#ifndef ADC_ADC_CONFIG_H_
#define ADC_ADC_CONFIG_H_



#endif /* ADC_ADC_CONFIG_H_ */
