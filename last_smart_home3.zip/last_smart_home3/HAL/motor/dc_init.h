/*
 * dc_init.h
 *
 *  Created on: Feb 22, 2023
 *      Author: mohamed
 */

#ifndef MOTOR_DC_INIT_H_
#define MOTOR_DC_INIT_H_

void H_DcMotor_void_init(void);
void H_DcMotor_void_ON(void);

void H_DcMotor_void_OF(void);

#endif /* MOTOR_DC_INIT_H_ */
