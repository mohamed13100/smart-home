/*
 * LM35_int.h
 *
 *  Created on: Feb 22, 2023
 *      Author: mohamed
 */

#ifndef LM35_LM35_INT_H_
#define LM35_LM35_INT_H_


void H_TempSensor_void_Init(void);

u16 H_TempSensor_u16_read(void) ;




#endif /* LM35_LM35_INT_H_ */
