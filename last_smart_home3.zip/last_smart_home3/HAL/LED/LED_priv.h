/*
 * LED_priv.h
 *
 *  Created on: Jan 31, 2023
 *      Author: aya_enan
 */

#ifndef LED_LED_PRIV_H_
#define LED_LED_PRIV_H_

#define LED_FORWARD  1
#define LED_REVERSE  0

#endif /* LED_LED_PRIV_H_ */
